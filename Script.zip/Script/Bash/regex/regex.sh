#!/bin/bash
csv=/Test/Donnée/ex2.csv
log=/Test/Donnée/log.txt

while read line
do
	if [[ "$line" =~ ^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$ ]]
	then
		continue
	else
		echo "Email address $line is invalid."
		echo "Email address $line is invalid." >>$log
		sed -i -e "/$line/d" $csv
	fi
done < $csv
