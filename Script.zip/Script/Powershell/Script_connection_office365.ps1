﻿#Connexion à Office365
$Cred = Get-Credential
$Session = New-PSSession -ConfigurationName Microsoft.Exchange -ConnectionUri https://outlook.office365.com/powershell-liveid/ -Credential $Cred -Authentication Basic -AllowRedirection
Import-PSSession $Session -AllowClobber
Import-Module msonline
Connect-msolservice -credential $Cred

#Deconnexion d'Office365
Get-PSSession | Remove-PSSession

#Suppression d'un compte Office365 (Suppression compte Azure et BAL Exchange)
Remove-MsolUser -UserPrincipalName dgrohl@cefim.ninja

#Restaurer un compte Office365 (30 jours - Restaure compte AzureAD et BAL)
Restore-MsolUser -UserPrincipalName dgrohl@cefim.ninja

#Obtenir la liste des utilisateurs supprimés d'Office365
Get-MsolUser -All -ReturnDeletedUsers

#Suppression des BAL présentes dans la période de rétention de 30 Jours (corbeille office365)
Get-MsolUser -All -ReturnDeletedUsers Remove-MsolUser -RemoveFromRecycleBin -Force

#Obtenir le source anchor d'un compte Azure office365
Get-MsolUser -UserPrincipalName ddurand@cefim.ninja | select ImmutableID

#Purge du source anchor du compte AzureAD dans le cadre d'une migration de comptes AD via ADMT lors d'une migration de forêt
#Pour vider le source anchor, il faut absolument couper la synchronisation AdConnect côté Office365
Set-MsolUser -UserPrincipalName fthauvin@cefim.ninja -ImmutableId "$null"

#Récupération dans un CSV des comptes en mode CLOUD ONLY
$b=Get-MsolUser -Synchronized:$false -DomainName "cefim.ninja" -All | Select-Object UserprincipalName | Export-CSV C:\cloudonly.csv

$b=Get-MsolUser -Synchronized:$false -DomainName "cefim.ninja" -Al
$b.count

#Récupération dans un CSV des comptes synchronisé avec un AD local
$a=Get-MsolUser -Synchronized:$true -DomainName "cefim.ninja" -All | Select-Object UserprincipalName | Export-CSV C:\synchro.csv

$a=Get-MsolUser -Synchronized:$true -DomainName "cefim.ninja" -All
$a.count

#Forcer la synchro ADConnect de votre AD Local vers Office365 en mode différentiel (si vous ne voulez pas attendre la synchro automatique d'ADConnect toutes les 30min)
#Commande à passer obligatoirement sur le serveur ADConnect
Start-ADSyncSyncCycle -PolicyType -delta 

#Forcer la synchro ADConnect de votre AD Local vers Office365 en mode complet (si vous ne voulez pas attendre la synchro automatique d'ADConnect toutes les 30min)
#Commande à passer obligatoirement sur le serveur ADConnect
Start-ADSyncSyncCycle -PolicyType -Initial

#Désactiver la synchro ADConnect
Set-AdSyncScheduler -SyncCycleEnabled $false

#Activer la synchro ADConnect
Set-AdSyncScheduler -SyncCycleEnabled $true

#Désactiver la synchro Office365 AD Connect (24h)
#Se logger sur Office365 en Admin
Set-MsolDirSyncEnabled -EnableDirSync $false -Force

#Activer la synchro Office365 AD Connect (une demi journée)
#Se logger sur Office365 en Admin
Set-MsolDirSyncEnabled -EnableDirSync $true -Force
