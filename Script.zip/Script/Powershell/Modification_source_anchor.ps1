﻿#Connexion à Office365
$Cred = Get-Credential
$Session = New-PSSession -ConfigurationName Microsoft.Exchange -ConnectionUri https://outlook.office365.com/powershell-liveid/ -Credential $Cred -Authentication Basic -AllowRedirection
Import-PSSession $Session -AllowClobber
Import-Module msonline
Connect-msolservice -credential $Cred

$a=Get-MsolUser -Synchronized:$false -DomainName "cefim.ninja" -All | Select-Object UserPrincipalName  | Export-Csv C:\sourceanchor.csv
$csv = "C:\sourceanchor.csv"
$colonneUPN = "UserPrincipalName"
$import = import-csv $csv
foreach($user in $import){
Set-MsolUser -UserPrincipalName $user.UserPrincipalName $User.$colonneUPN -ImmutableId "$null"
Write-Host -ForegroundColor Yellow ("Le source anchor du compte " + $user.$colonneUPN + " a été passé à la valeur null")
}