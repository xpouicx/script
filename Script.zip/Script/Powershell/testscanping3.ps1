﻿$range = 1..254
$réseau=Read-Host "Spécifiez l'addresse du réseau à scanner"
$address=$réseau+"."+ $range
$range | ForEach-Object {
  Write-Progress “Scanning Network” $address -PercentComplete (($_/$range.Count)*100)
  New-Object PSObject -Property @{
    Address = $address
    Ping = Test-Connection $address -Quiet -Count 1
  }
} | Out-File C:\Users\TSSR\Desktop\ipscan.csv