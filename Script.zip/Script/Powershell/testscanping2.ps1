﻿$range = 1..254
$réseau=Read-Host "Spécifiez l'addresse du réseau à scanner"
$address=$réseau+"."+ $range
write-host $address